# 金字塔v3数据合同

合同版本 `pyramid-v3.1`。实现 `src/book_ocr/pyramid.py`；机器输出格式 `config/knowledge-v3/*.schema.json`。本合同检查知识提炼的结构、来源和覆盖，直接使用用户接受的OCR文本。

## 原文单元

每个单元保存unit_id、book_id、完整正文pieces、真实章节/小节边界状态、原文页/章节定位、原结果文件哈希、文字哈希和图像引用。每个piece有稳定source_id、evidence_id及原字符串span_start/span_end。引用quote是该piece中连续原文；字符偏移按Python Unicode字符串计数，不按字节数。

BOOK-0005旧来源ID保持 `BOOK-0005-P0009-B0000-v1`，不改写既有539条evidence。新增span只作为定位补充。当前页级生成器仅供校准样例，不把页面当作已确认语义小节。正式L1仍须在K05确认跨页章/节边界。

EPUB、原生文本与附录以真实章节/源成员定位；不得复制PDF物理页定位假装原生页。K05在同一合同中扩展实际来源适配器。

## 卡片与覆盖

卡片包括claim、claim_type、reasoning、examples、terms、conditions、exceptions、parameters、unresolved_terms和references。单元初读不允许冒称cross_source_synthesis或validated_result。参数无明确值时保留unknown/未定义项；语义忠实性仍需原文复核，结构检查不替代它。

每个piece有且仅有一条coverage，注明extracted/context/repeated/unresolved、关联card_ids及具体理由。提炼/重复的段落必须关联有真实引文的卡片。所有有实质内容却被归为context的项目进入后续遗漏检查；不会因覆盖字段齐全就认定读懂。

## 图表、主题与规则

视觉对象保存object_id、description、axes、units、legends、visible_numbers、formula、interpretation、unresolved及输入图像哈希；输出内容要与真实图像复核，不能只读图注。

主题保存来源卡片集合、定义、背景、条件、共识、分歧、例外与未决项。关系类型区分同条件相反、条件不同、定义不同及未判定。来源不存在或关系指向集合外的卡片会被拒绝。

规则保存短句、完整解释、观点身份、范围、条件、例外、失效、未定义项和L2/L3来源。实证状态需真实存在的报告路径；无报告的文献知识保持literature_only。程序不会根据书籍观点生成收益认证。

## 存储与兼容

K02只是合同与真实样例，不迁移或覆盖旧知识数据库。K04新增版本化任务/产物账本，K05及内容任务再实现实际入库；每次提交包绑定输入、模型、提示词、合同与输出哈希，内容状态与任务执行状态分开。一个已提交包是权威记录，可读视图和检索由它生成，禁止SQLite和Markdown各自独立修改成不同事实。

样例与校验位于 `state/knowledge-tasks/K02/`；它证明合同可用，不证明第一章或全书已经读完。
